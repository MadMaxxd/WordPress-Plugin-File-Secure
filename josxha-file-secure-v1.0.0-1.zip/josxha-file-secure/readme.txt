=== Restrict File Access ===
Contributors: Joscha Eckert
Donate link: https://www.paypal.me/joschaeckert
Tags: restrict, file, secure, sicher, schützen, angemeldet, Dateien, login, permission, Joscha, Eckert, josxha, privat, private
Requires at least: 4.9
Tested up to: 5.1.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Schütze hochgeladene Dateien vor unbefugtem Zugriff.

== Description ==

Schütze hochgeladene Dateien vor unbefugtem Zugriff.
There is currently only a German version available.

== Installation ==

1. Upload the entire `josxha-file-secure` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

or install it via 'Upload plugins' on the plugin page of your website.

== Screenshots ==

== Changelog ==

For more information, have a look at the [GitHub project](https://github.com/josxha/WordPress-Plugin-File-Secure).

= 1.0.0 =

* stable release of the plugin